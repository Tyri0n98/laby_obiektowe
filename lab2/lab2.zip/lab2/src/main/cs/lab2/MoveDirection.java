package cs.lab2;

/**
 * Created by Student40 on 2018-10-09.
 */
public enum MoveDirection {
    FORWARD,
    BACKWARD,
    RIGHT,
    LEFT

}
